# VPKEdit

CLI tool for extracting files from Valve's VPK archives (Portal 2, TF2, HL2, etc.).

**Project**: https://github.com/craftablescience/VPKEdit  
**License**: MIT — https://github.com/craftablescience/VPKEdit/blob/main/LICENSE  
**Version used**: 4.3.5 (vpkeditcli.exe, Windows x64)  
**Download**: GitHub Releases → `vpkedit-windows-x64.zip`

The binaries (`vpkeditcli.exe`, `vpkedit.exe`, `previews/`) are not committed — Windows-specific
binary blobs. Download and place `vpkeditcli.exe` in this directory before running the pipeline.

## Usage

```bat
# Extract a single file (must specify full output path, not a directory)
vpkeditcli --extract "models/props/metal_box.mdl" -o desktop/extracted/models/props/metal_box.mdl portal2/pak01_dir.vpk

# Extract a directory subtree
vpkeditcli --extract "materials/models/props/" desktop/extracted/ portal2/pak01_dir.vpk
```

Run from the project root. The PAK path for Portal 2 on a default Steam install is:
`C:\Program Files (x86)\Steam\steamapps\common\Portal 2\portal2\pak01_dir.vpk`
