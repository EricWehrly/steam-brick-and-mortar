from typing import Collection

from SourceIO.library.shared.content_manager.detectors.source1 import Source1Detector
from SourceIO.library.shared.content_manager.provider import ContentProvider
from SourceIO.library.shared.content_manager.providers.source1_gameinfo_provider import Source1GameInfoProvider
from SourceIO.library.shared.content_manager.providers.vpk_provider import VPKContentProvider
from SourceIO.library.utils import backwalk_file_resolver, TinyPath


class InfraDetector(Source1Detector):

    @classmethod
    def game(cls) -> str:
        return "Infra"

    @classmethod
    def find_game_root(cls, path: TinyPath) -> TinyPath | None:
        infra_exe = backwalk_file_resolver(path, 'infra.exe')
        if infra_exe is not None:
            return infra_exe.parent
        return None

    @classmethod
    def scan(cls, path: TinyPath) -> tuple[Collection[ContentProvider] | None, TinyPath | None]:
        infra_root = cls.find_game_root(path)
        if infra_root is None:
            return None, None
        providers = set()
        initial_mod_gi_path = backwalk_file_resolver(path, "gameinfo.txt")
        if initial_mod_gi_path is not None:
            cls.add_provider(Source1GameInfoProvider(initial_mod_gi_path), providers)
        for vpk_path in initial_mod_gi_path.parent.glob("*.vpk"):
            with vpk_path.open("rb") as f:
                if f.read(4) != b"\x34\x12\xAA\x55":
                    continue
            cls.add_provider(VPKContentProvider(vpk_path), providers)

        infra_mod_gi_path = infra_root / "infra/gameinfo.txt"
        if initial_mod_gi_path != infra_mod_gi_path:
            cls.add_provider(Source1GameInfoProvider(infra_mod_gi_path), providers)
        for vpk_path in infra_mod_gi_path.parent.glob("*.vpk"):
            with vpk_path.open("rb") as f:
                if f.read(4) != b"\x34\x12\xAA\x55":
                    continue
            cls.add_provider(VPKContentProvider(vpk_path), providers)

        cls.register_common(infra_root, providers)
        return providers, infra_root
